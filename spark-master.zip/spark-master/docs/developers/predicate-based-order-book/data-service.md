# Data Service

{% embed url="https://github.com/compolabs/spark-data-service" %}

We have implemented a Spark data service using Node.js, which serves as a cache and performs calculations on its side to improve the performance of the frontend. By delegating data processing to the Spark backend, we can significantly boost the speed of frontend operations.
