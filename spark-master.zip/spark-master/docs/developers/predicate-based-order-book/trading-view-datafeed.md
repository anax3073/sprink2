# Trading View Datafeed



{% embed url="https://github.com/compolabs/spark-tv-datafeed" %}

\
Our service creates trades in a database by matching fully or partially closed orders. These trades are then displayed on the TradingView chart. Traders can also use this data for backtesting purposes. Additionally, the TradingView data feed API returns data to the frontend to generate candle charts.
