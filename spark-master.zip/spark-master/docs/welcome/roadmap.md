# Roadmap

* [x] **Eth Denver (Mar 5)**\
  Spark Concept App
* [x] **Eth Porto (Mar 18)**\
  Introduction of the Predicate-driven orders
* [x] **Eth Global (Lisbon, May 12)**\
  Spark Demo Launch
* [ ] **Eth Global (Paris, July 23)**\
  Predicate-based spark Launch
*   [ ] **Jun-Oct**

    Product Testing and improvements
* [ ] **Eth Lisbon Nov 1**\
  Product and Token Launch
