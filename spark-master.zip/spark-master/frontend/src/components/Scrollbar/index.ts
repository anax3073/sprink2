import Scrollbar from "./Scrollbar";

export default Scrollbar;
