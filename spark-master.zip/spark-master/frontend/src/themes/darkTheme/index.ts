import colors from "./colors";
import images from "./images";
// eslint-disable-next-line
export default {
  colors,
  images,
};
