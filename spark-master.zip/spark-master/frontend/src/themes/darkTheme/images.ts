// eslint-disable-next-line
export default {
  icons: {
    logo: require("@src/assets/icons/dark-logo.svg").default,
    arrowDown: require("@src/assets/icons/arrow.svg").default,
    wallet: require("@src/assets/icons/wallet-dark.svg").default,
    coins: require("@src/assets/icons/coins-dark.svg").default,
    rightArrow: require("@src/assets/icons/rightArrow-dark.svg").default,
  },
};
