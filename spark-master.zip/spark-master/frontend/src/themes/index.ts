import darkThemeColors from "./darkTheme/colors";
// import lightThemeColors from "./lightTheme/colors";
import { rem } from "./rem";
const lightThemeColors = darkThemeColors;
export { darkThemeColors, lightThemeColors, rem };
