import Trades from "./Trades";

export default Trades;
