import Chart from "./Chart";

export default Chart;
